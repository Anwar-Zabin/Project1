﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Project1.Entities;

namespace Project1
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Department> Departments { get; set; }
        public DbSet<Position> Positions { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<VacationType> VacationTypes { get; set; }
        public DbSet<RequestState> RequestStates { get; set; }
        public DbSet<VacationRequest> VacationRequests { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=ANWAR-PC\\MSSQLSERVER01;Database=Company;Trusted_Connection=True;TrustServerCertificate=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure Employee Self-Reference
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.ReportedTo)
                .WithMany()
                .HasForeignKey(e => e.ReportedToEmployeeNumber);

            // Configure VacationRequest Relationships
            modelBuilder.Entity<VacationRequest>()
                .HasOne(vr => vr.ApprovedByEmployee)
                .WithMany(e => e.ApprovedRequests)
                .HasForeignKey(vr => vr.ApprovedByEmployeeNumber);

            modelBuilder.Entity<VacationRequest>()
                .HasOne(vr => vr.DeclinedByEmployee)
                .WithMany(e => e.DeclinedRequests)
                .HasForeignKey(vr => vr.DeclinedByEmployeeNumber);


            using (var context = new ApplicationDbContext())
            {
                var departments = new List<Department>
        {
            new Department { DepartmentName = "HR" },
            new Department { DepartmentName = "IT" },
            new Department { DepartmentName = "Finance" },
            new Department { DepartmentName = "Marketing" },
            new Department { DepartmentName = "Sales" },
            new Department { DepartmentName = "Operations" },
            new Department { DepartmentName = "Customer Support" },
            new Department { DepartmentName = "Engineering" },
            new Department { DepartmentName = "Legal" },
            new Department { DepartmentName = "Research & Development" },
            new Department { DepartmentName = "Admin" },
            new Department { DepartmentName = "Public Relations" },
            new Department { DepartmentName = "Business Strategy" },
            new Department { DepartmentName = "Logistics" },
            new Department { DepartmentName = "Procurement" },
            new Department { DepartmentName = "Security" },
            new Department { DepartmentName = "Compliance" },
            new Department { DepartmentName = "Health & Safety" },
            new Department { DepartmentName = "Training & Development" },
            new Department { DepartmentName = "Quality Assurance" }
        };

                foreach (var dept in departments)
                {
                    context.Add(dept); 
                }

                context.SaveChanges(); 
                Console.WriteLine("Departments added successfully!");
            }

            using (var context = new ApplicationDbContext())
            {
                var positions = new List<Position>
        {
            new Position { PositionName = "Manager" },
            new Position { PositionName = "Developer" },
            new Position { PositionName = "Accountant" },
            new Position { PositionName = "HR Specialist" },
            new Position { PositionName = "Marketing Coordinator" },
            new Position { PositionName = "Sales Executive" },
            new Position { PositionName = "Operations Analyst" },
            new Position { PositionName = "Customer Support Lead" },
            new Position { PositionName = "Software Engineer" },
            new Position { PositionName = "Legal Advisor" },
            new Position { PositionName = "Data Scientist" },
            new Position { PositionName = "Office Administrator" },
            new Position { PositionName = "Public Relations Officer" },
            new Position { PositionName = "Business Consultant" },
            new Position { PositionName = "Logistics Coordinator" },
            new Position { PositionName = "Procurement Officer" },
            new Position { PositionName = "Security Manager" },
            new Position { PositionName = "Compliance Officer" },
            new Position { PositionName = "Health & Safety Inspector" },
            new Position { PositionName = "Quality Control Specialist" }
        };

                context.Positions.AddRange(positions); // Using DbSet 
                context.SaveChanges();
                Console.WriteLine("Positions added successfully!");
            }
        }
    }
}
