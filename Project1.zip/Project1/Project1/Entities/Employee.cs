﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Entities
{
    public class Employee
    {
        [Key,MaxLength(6)]
        public string EmployeeNumber { get; set; }
        [Required, MaxLength(20)]
        public string EmployeeName { get; set; } = null!;
        public int? DepartmentId { get; set; } // FK
        public int? PositionId { get; set; } // FK
        [MaxLength(1)]
        public string GenderCode { get; set; } // Max 1 char (M/F)
        [MaxLength(6)]
        public string? ReportedToEmployeeNumber { get; set; } // Nullable
        [Range(0,24)]
        public int VacationDaysLeft { get; set; } // Default 24
        public decimal Salary { get; set; } 

        public Department? Department { get; set; }
        public Position? Position { get; set; } 
        public Employee? ReportedTo { get; set; }
        public ICollection<VacationRequest> VacationRequests { get; set; }
        public ICollection<VacationRequest> ApprovedRequests { get; set; }
        public ICollection<VacationRequest> DeclinedRequests { get; set; }

        public Employee()
        {
            VacationDaysLeft = 24;
        }

    }
}
