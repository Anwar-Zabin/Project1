﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Project1.Entities
{
    internal class ReportingService
    {
        private readonly ApplicationDbContext _context;

        public ReportingService(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<dynamic> GetAllEmployees()
        {
          
            var query = from emp in _context.Employees
                        join dept in _context.Departments on emp.DepartmentId equals dept.DepartmentId
                        select new
                        {
                            emp.EmployeeNumber,
                            emp.EmployeeName,
                            Department = dept.DepartmentName,
                            emp.Salary
                        };

            return query.ToList<dynamic>();
        }

        
        public dynamic GetEmployeeByNumber(string employeeNumber)
        {
            return _context.Employees
                .Include(e => e.Department) 
                .Include(e => e.Position)
                .Include(e => e.ReportedTo)
                .Where(e => e.EmployeeNumber == employeeNumber)
                .Select(e => new
                {
                    e.EmployeeNumber,
                    e.EmployeeName,
                    DepartmentName = e.Department.DepartmentName,
                    PositionName = e.Position.PositionName,
                    ReportedToEmployeeName = e.ReportedTo != null ?
                        e.ReportedTo.EmployeeName : "None",
                    e.VacationDaysLeft
                })
                .FirstOrDefault();
        }

        public List<dynamic> GetEmployeesWithPendingRequests()
        {
            
            return _context.Employees
                .Where(e => e.VacationRequests.Any(vr => vr.RequestStateId == 1))
                .Select(e => new
                {
                    e.EmployeeNumber,
                    e.EmployeeName,
                    PendingRequests = e.VacationRequests.Count(vr => vr.RequestStateId == 1)
                })
                .ToList<dynamic>();
        }

        
        public List<dynamic> GetApprovedVacationRequests()
        {
            
            var query = from vr in _context.VacationRequests
                        join vt in _context.VacationTypes on vr.VacationTypeCode equals vt.VacationTypeCode
                        join emp in _context.Employees on vr.ApprovedByEmployeeNumber equals emp.EmployeeNumber
                        where vr.RequestStateId == 2 
                        select new
                        {
                            VacationType = vt.VacationTypeName,
                            vr.Description,
                            Duration = $"{vr.TotalVacationDays} days",
                            ApprovedBy = emp.EmployeeName
                        };

            return query.ToList<dynamic>();
        }
    }
}
