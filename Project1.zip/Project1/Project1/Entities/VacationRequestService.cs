﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Project1.Entities
{
    internal class VacationRequestService
    {
        private readonly ApplicationDbContext _context;

        public VacationRequestService(ApplicationDbContext context)
        {
            _context = context;
        }

        public bool SubmitVacationRequest(VacationRequest request)
        {
           
            var overlappingRequest = _context.VacationRequests
                .Where(vr => vr.EmployeeNumber == request.EmployeeNumber &&
                            vr.RequestStateId != 3 && 
                            ((request.StartDate >= vr.StartDate && request.StartDate <= vr.EndDate) ||
                             (request.EndDate >= vr.StartDate && request.EndDate <= vr.EndDate) ||
                             (request.StartDate <= vr.StartDate && request.EndDate >= vr.EndDate)))
                .FirstOrDefault();

            if (overlappingRequest != null)
            {
                return false;
            }

            request.StartDate = DateTime.Now;
            request.RequestStateId = 1;
            request.TotalVacationDays = (int)(request.EndDate - request.StartDate).TotalDays;

            
            _context.VacationRequests.Add(request);
            _context.SaveChanges(); 

            return true;
        }

        
        public List<VacationRequest> GetPendingRequestsForApproval(string employeeNumber)
        {
            
            return _context.VacationRequests
                .Include(vr => vr.Employee) 
                .Include(vr => vr.VacationType) 
                .Where(vr => vr.Employee.ReportedToEmployeeNumber == employeeNumber &&
                             vr.RequestStateId == 1) 
                .ToList();
        }

        // 3a. Approve vacation request
        public bool ApproveRequest(int requestId, string approverEmployeeNumber)
        {
            var request = _context.VacationRequests
                .Include(vr => vr.Employee)
                .FirstOrDefault(vr => vr.RequestId == requestId);

            if (request == null || request.Employee.VacationDaysLeft < request.TotalVacationDays)
            {
                return false;
            }

            
            request.RequestStateId = 2; 
            request.ApprovedByEmployeeNumber = approverEmployeeNumber;
            request.DeclinedByEmployeeNumber = null;

            
            request.Employee.VacationDaysLeft -= request.TotalVacationDays;

            _context.SaveChanges(); 
            return true;
        }

        // Decline vacation request
        public bool DeclineRequest(int requestId, string declinerEmployeeNumber)
        {
            var request = _context.VacationRequests
                .FirstOrDefault(vr => vr.RequestId == requestId);

            if (request == null)
            {
                return false;
            }

            request.RequestStateId = 3; 
            request.DeclinedByEmployeeNumber = declinerEmployeeNumber;
            request.ApprovedByEmployeeNumber = null;

            _context.SaveChanges();
            return true;
        }

    }
}
