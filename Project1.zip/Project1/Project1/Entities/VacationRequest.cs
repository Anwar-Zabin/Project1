﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Entities
{
    public class VacationRequest
    {
        [Key]
        public int RequestId { get; set; }
        [Required]
        public DateTime SubmissionDate { get; set; }
        [MaxLength(100),Required]
        public string Description { get; set; }
        public string EmployeeNumber { get; set; } = null!; // FK
        public string VacationTypeCode { get; set; } = null!; // FK
        [Required]
        public DateTime StartDate { get; set; } 
        [Required]
        public DateTime EndDate { get; set; } 
        [Required]
        public int TotalVacationDays { get; set; } 
        public int RequestStateId { get; set; } // FK
        public string? ApprovedByEmployeeNumber { get; set; } // Nullable
        public Employee? ApprovedByEmployee { get; set; }
        public string? DeclinedByEmployeeNumber { get; set; } // Nullable
        public Employee? DeclinedByEmployee { get; set; }

        public Employee Employee { get; set; } = null!; // Navigation Property
        public VacationType VacationType { get; set; } = null!; // Navigation Property
        public RequestState RequestState { get; set; } // Navigation Property
    }
}
