﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Entities
{
     public class Department
    {
        [Key]
        public int DepartmentId { get; set; }
        [Required, MaxLength(50)]
        public string DepartmentName { get; set; } = null!;

        public ICollection<Employee> Employees { get; set; } 
    }
}
